package com.example.spinner

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val respuesta = findViewById<TextView>(R.id.txt_respuesta)
        val spinner= findViewById<Spinner>(R.id.spr_1)
        val btn_operar = findViewById<Button>(R.id.btn_ok)


        val lista = arrayOf("Carne", "Pollo", "Pescado", "Carne de Chancho")
        val adaptador1 = ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, lista)
        spinner.adapter = adaptador1
        btn_operar.setOnClickListener {
            when (spinner.selectedItem.toString()) {

                "Carne" -> respuesta.text =
                    "${"$2.50 la libra"}"

                "Pollo" -> respuesta.text =
                    "${"$7.00 pollo entero" }"

                "Pescado" -> respuesta.text =
                    "${"$3.00 cada pescado"}"

                "Carne de Chancho" -> respuesta.text =
                    "${"$4.00 la libra"}"


            }
        }
    }
}